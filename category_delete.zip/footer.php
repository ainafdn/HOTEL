<?php require('config.php'); ?>
<center><FONT SIZE="1" COLOR="black" font face="Arial">Copyright &copy;
<?php echo $sysname; ?> 2019</center>